import { useEffect, useState } from 'react';
import api from '../utils/api';

export default function Dashboard() {
  const [profile, setProfile] = useState('');
  const [skill, setSkill] = useState('');
  const [roadmap, setRoadmap] = useState('');

  const generateRoadmap = async () => {
    const res = await api.post('/api/roadmap/', { profile, skill });
    setRoadmap(res.data.roadmap);
  };

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">Manager Dashboard</h1>
      <input className="border p-2 mb-2 w-full" placeholder="Employee Profile" value={profile} onChange={e => setProfile(e.target.value)} />
      <input className="border p-2 mb-2 w-full" placeholder="Skill to Learn" value={skill} onChange={e => setSkill(e.target.value)} />
      <button onClick={generateRoadmap} className="bg-green-500 text-white px-4 py-2 mb-4">Generate Roadmap</button>
      {roadmap && <pre className="bg-gray-100 p-4 rounded">{roadmap}</pre>}
    </div>
  );
}

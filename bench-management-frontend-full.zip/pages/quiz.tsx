export default function Quiz() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">Quiz Page</h1>
      <p>This page will handle quiz interaction.</p>
    </div>
  );
}

from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Skill, Employee
from .serializers import SkillSerializer, EmployeeSerializer
from .ai.roadmap_generator import generate_roadmap
from .ai.quiz_generator import generate_quiz

@api_view(['POST'])
def roadmap(request):
    profile = request.data.get("profile", "")
    desired_skill = request.data.get("skill", "")
    roadmap = generate_roadmap(profile, desired_skill)
    return Response({"roadmap": roadmap})

@api_view(['POST'])
def quiz(request):
    skill = request.data.get("skill", "")
    quiz = generate_quiz(skill)
    return Response({"quiz": quiz})

import openai

def generate_quiz(skill):
    prompt = f"Create 5 multiple-choice questions with answers for learning {skill}."
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )
    return response['choices'][0]['message']['content']

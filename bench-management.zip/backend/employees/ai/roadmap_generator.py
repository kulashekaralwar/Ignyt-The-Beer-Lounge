import openai

def generate_roadmap(profile, skill):
    prompt = f"A user profile:\n{profile}\n\nGenerate a roadmap to learn {skill}."
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )
    return response['choices'][0]['message']['content']

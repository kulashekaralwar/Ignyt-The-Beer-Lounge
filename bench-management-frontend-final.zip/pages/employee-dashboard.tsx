import { useEffect, useState } from 'react';
import api from '../utils/api';

export default function EmployeeDashboard() {
  const [skills, setSkills] = useState([]);
  const [selectedSkill, setSelectedSkill] = useState('');
  const [quiz, setQuiz] = useState('');

  useEffect(() => {
    const fetchSkills = async () => {
      const token = localStorage.getItem('token');
      const res = await api.get('/api/skills/', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setSkills(res.data);
    };
    fetchSkills();
  }, []);

  const handleSkillSelection = async () => {
    const token = localStorage.getItem('token');
    const res = await api.post('/api/quiz/', { skill: selectedSkill }, {
      headers: { Authorization: `Bearer ${token}` }
    });
    setQuiz(res.data.quiz);
  };

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">Employee Dashboard</h1>
      <select value={selectedSkill} onChange={(e) => setSelectedSkill(e.target.value)} className="border p-2 mb-4 w-full">
        <option value="">Select Skill</option>
        {skills.map((skill) => (
          <option key={skill.id} value={skill.name}>{skill.name}</option>
        ))}
      </select>
      <button onClick={handleSkillSelection} className="bg-blue-500 text-white px-4 py-2">Generate Quiz</button>
      {quiz && <div className="whitespace-pre-wrap bg-gray-100 p-4 rounded">{quiz}</div>}
    </div>
  );
}

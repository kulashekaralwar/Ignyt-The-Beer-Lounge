import { useState } from 'react';
import api from '../utils/api';

export default function Quiz() {
  const [skill, setSkill] = useState('');
  const [quiz, setQuiz] = useState('');

  const fetchQuiz = async () => {
    const res = await api.post('/api/quiz/', { skill });
    setQuiz(res.data.quiz);
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Quiz Generator</h2>
      <input className="border p-2 mb-2 w-full" placeholder="Skill Name" value={skill} onChange={(e) => setSkill(e.target.value)} />
      <button onClick={fetchQuiz} className="bg-purple-500 text-white px-4 py-2 mb-4">Generate Quiz</button>
      {quiz && <div className="whitespace-pre-wrap bg-gray-100 p-4 rounded">{quiz}</div>}
    </div>
  );
}
